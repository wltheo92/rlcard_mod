name = "rlcard"
__version__ = "1.2.0"

from rlcard.envs import make
